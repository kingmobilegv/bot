from bot.cogs.modules.database import *


def group_list():
    grupos = all_groups()
    
    return grupos



