import requests, re, random, time
from fordev import generators
from fordev.generators import people
import json


with open('config/config_checker.json', 'r', encoding='UTF-8') as file:
    pagarme_c = json.loads(file.read())['pagarme']
    api_key = pagarme_c['api_key']


def pagarme(full):
    import time
    time.sleep(4)
    if len(full.split("|")) == 4:
        ccn, mes, ano, cvv = full.split("|")
        
        if len(ano) == 2:
            ano = '20'+ano
        
        url = "https://api.pagar.me/1/transactions"
        
        headers = {
        "Content-Type": "application/json"
        }
        
        dados = people()
        
        with open('assets/db_emails.json', 'r') as file2:
            load = json.loads(file2.read())
            emails = load['emails']
            email = random.choice(emails)
        
        endereco = generators.people(
            uf_code=generators.uf()[0],
            data_only=True
        )
        
        debitar = random.randint(100, 200)
        data = {
            "api_key": api_key,
            "amount": debitar,
            "card_number": ccn,
            "card_cvv": cvv,
            "card_expiration_date": mes + ano[2:],
            "card_holder_name": dados["nome"].upper(),
            "customer": {
                "external_id": str(random.randint(111111,999999)),
                "name": dados["nome"].upper(),
                "type": "individual",
                "country": "br",
                "email": email,
                "documents": [
                    {
                        "type": "cpf",
                        "number": dados["cpf"]
                    }
                ],
                "phone_numbers": [
                    "+55" + re.sub(
                        "[^0-9]+", "", endereco["celular"]
                    )
                ],
                "birthday": "-".join(
                    reversed(
                        dados["data_nasc"].split("/")
                    )
                )
            },
            "billing": {
                "name": dados["nome"],
                "address": {
                    "country": "br",
                    "state": endereco["estado"],
                    "city": endereco["cidade"],
                    "neighborhood": endereco["bairro"],
                    "street": endereco["endereco"],
                    "street_number": str(endereco["numero"]),
                    "zipcode": endereco["cep"].replace("-", "")
                }
            },
            "shipping": {
                "fee": 000,
                "name": dados["nome"],
                "address": {
                    "country": "br",
                    "state": endereco["estado"],
                    "city": endereco["cidade"],
                    "neighborhood": endereco["bairro"],
                    "street": endereco["endereco"],
                    "street_number": str(endereco["numero"]),
                    "zipcode": endereco["cep"].replace("-", "")
                }
            },
            "items": [
                {
                    "id": "SF280",
                    "title": "Check-in Demo",
                    "unit_price": debitar,
                    "quantity": 1,
                    "tangible": True
                }
            ]
    
        }
        

        try:
            response = requests.post(
                url,
                headers=headers,
                json=data
            ).json()
            print(response)
            with open('retorno.txt', 'a') as file:
                file.write(str(response)+'\n\n')
            
            
            preco = str(debitar)
            preco = f'R${preco[0]},{preco[1]}{preco[2]}'
            code = response['acquirer_response_code']
                
            if "status" not in response.keys():
                return False, 'Erro na comunicação com o Gateway'
    
            elif response["acquirer_response_code"] == "0000":
            
                return True, f'Transação autorizada - Code: {code} - {preco}'
        
            else:        
                return False, f'Transação não autorizada - Code: {code} - {preco}'
            
        except:
            return False, 'Request inválido ao Gateway'
        
    else:
        return False, 'Parâmetros insuficientes'

