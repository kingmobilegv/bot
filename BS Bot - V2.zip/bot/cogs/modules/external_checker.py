import uncurl, requests, validators


def curl_validate(command):
    cc = '1'
    numero = '2'
    cvv = '3'
    ano = '4'
    mes = '5'
    
    curl = command.format(cc=cc, numero=numero, cvv=cvv, ano=ano, mes=mes)
    
    if '{cc}' in command or '{numero}' in command or '{ano}' in command or '{mes}' in command or '{cvv}' in command:
        if not 'curl' in curl.lower():
            curl = 'curl '+curl

        try:
            a = str(uncurl.parse(curl))+'.text'
            return True
        except:
            return 'Ocorreu um erro ao validar a sua URL ou Curl\n\nCertifique-se que a url seja uma url válida (com https:// ou http:// e sem espaços ou caracteres inválidos) ou o comando Curl seja um comando válido!'

    else:
        return "Cerifique-se de incluir as variáveis quando a CC for usada no checker!\n\n*O que são variáveis?* Nesse caso, variáveis são espaços de memória parcial ou completo da CC, que deve ser incluido na URL no lugar da CC.\n\nExemplo: `https://exemple.com/checker.php?lista={cc}`,\n`curl 'https://exemple.com/cielo?numero={numero}&mes={mes}&ano={ano}&cvv={cvv}' -H 'Content-Type: application/json'`\n\n*Variáveis*:\n\n{cc}: `CC completa em formato PIPE padrão`\n{numero}: `Número da CC`\n{mes}: `Mês de vencimento da CC`\n{ano}: `Ano de vencimento da CC (4 dígitos)`\n{cvv}: `Código de segurança de 3 a 4 dígitos da CC`"


print(curl_validate('https://apple.com/'))
