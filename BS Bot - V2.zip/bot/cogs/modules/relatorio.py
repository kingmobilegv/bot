from bot.cogs.modules.database import *
from datetime import datetime, timedelta, date
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
import numpy as np
import dufte
import time


def time_diference(start_time):
    try:
        start_time = float(start_time)
        elapsed_time_secs = time.time() - start_time

        msg = str(timedelta(seconds=round(elapsed_time_secs))).split(':')

        hora = msg[0]

        if int(hora) <= 24:
            return True, int(hora)
        else:
            return False, ''
    except: 
        return False, ''


def ccs_compradas():
    h0 = []
    h1 = []
    h2 = []
    h3 = []
    h4 = []
    h5 = []
    h6 = []
    h7 = []
    h8 = []
    h9 = []
    h10 = []
    h11 = []
    h12 = []
    h13 = []
    h14 = []
    h15 = []
    h16 = []
    h17 = []
    h18 = []
    h19 = []
    h20 = []
    h21 = []
    h22 = []
    h23 = []
    h24 = []


    ccs = []
    for cc in all_ccs_compradas():
        check = time_diference(cc[12])
        if check[0]:
            if check[1] == 0:
                h0.append('.')
            
            elif check[1] == 1:
                h1.append('.')
            
            elif check[1] == 2:
                h2.append('.')
                
            elif check[1] == 3:
                h3.append('.')
                
            elif check[1] == 4:
                h4.append('.')
                
            elif check[1] == 5:
                h5.append('.')
                
            elif check[1] == 6:
                h6.append('.')
                
            elif check[1] == 7:
                h7.append('.')
                
            elif check[1] == 8:
                h8.append('.')
                
            elif check[1] == 9:
                h9.append('.')
                
            elif check[1] == 10:
                h10.append('.')
                
            elif check[1] == 11:
                h11.append('.')
                
            elif check[1] == 12:
                h12.append('.')
                
            elif check[1] == 13:
                h13.append('.')
                
            elif check[1] == 14:
                h14.append('.')
                
            elif check[1] == 15:
                h15.append('.')
                
            elif check[1] == 16:
                h16.append('.')
                
            elif check[1] == 17:
                h17.append('.')
                
            elif check[1] == 18:
                h18.append('.')
                
            elif check[1] == 19:
                h19.append('.')
                
            elif check[1] == 20:
                h20.append('.')
                
            elif check[1] == 21:
                h21.append('.')
                
            elif check[1] == 22:
                h22.append('.')
                
            elif check[1] == 23:
                h23.append('.')
                
            elif check[1] == 24:
                h24.append('.')
                
            ccs.append(cc[0])

    data_atual = datetime.now()
    hora = data_atual.hour

    new = []
    results = [[0-hora, len(h0)], [1-hora, len(h1)], [2-hora, len(h2)], [3-hora, len(h3)], [4-hora, len(h4)], [5-hora, len(h5)], [6-hora, len(h6)], [7-hora, len(h7)], [8-hora, len(h8)], [9-hora, len(h9)], [10-hora, len(h10)], [11-hora, len(h11)], [12-hora, len(h12)], [13-hora, len(h13)], [14-hora, len(h14)], [15-hora, len(h15)], [16-hora, len(h16)], [17-hora, len(h17)], [18-hora, len(h18)], [19-hora, len(h19)], [20-hora, len(h20)], [21-hora, len(h21)], [22-hora, len(h22)], [23-hora, len(h23)], [24-hora, len(h24)]]
    for result in results:
        hora_compra = str(result[0]).replace('-', '')+'h'
        new.append([hora_compra, result[1]])

    return new, len(ccs)


def ccs_recusadas():
    ccs = []
    for cc in all_dies():
        check = time_diference(cc[1])
        if check[0]:
            ccs.append(cc[0])
        
    return '\n'.join(ccs)



def create_img():
    labels = []
    vals = []
    for cc in ccs_compradas()[0]:
        labels.append(cc[0])
        vals.append(cc[1])
        
    xpos = range(len(vals))

    with plt.style.context(dufte.style):

        plt.figure(figsize=(20, 5)) 
        plt.bar(xpos, vals, align='center', width=1, ec="k")
        plt.xticks(xpos, labels)


        plt.title("CCs vendidas nas ultimas 24 horas")
        plt.savefig("relatorio.png", transparent=False, bbox_inches="tight")
        plt.close()


def relatorio():
    create_img()
    ccs_die = ccs_recusadas()
    die = len(ccs_die.split('\n'))
    quantidade = ccs_compradas()[1]

    with open('temp/relatorio.txt', 'w') as file:
        file.write(f'Relatório das ultimas 24 horas:\n\nCCs vendidas: {quantidade}\nCCs rejeitadas: {die}\n\nCCs Rejeitadas:\n\n{ccs_die}')

    return f'**Relatório das ultimas 24 horas**:\n\n**CCs vendidas**: `{quantidade}`\n**CCs rejeitadas**: `{die}`'


