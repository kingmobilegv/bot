from datetime import datetime
from random import randint
import json, requests


def data(ts):
    t = datetime.utcfromtimestamp(float(ts))

    ano = t.year
    mes = t.month
    dia = t.day
    hora = t.hour
    minutos = t.minute

    return f'{mes:02}/{dia:02}/{ano:02}, {hora:02}:{minutos:02}'


def people():
    with open("assets/pessoas.json", "r", encoding="utf8") as f:
        r = json.load(f)
        pessoas = r['pessoa']
        q = len(pessoas)
        pessoa = pessoas[randint(0, q-1)]

        cpf = pessoa['cpf']
        nome = pessoa['nome']

        return cpf, nome

