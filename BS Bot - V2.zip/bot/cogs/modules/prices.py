def preco_img(content):
    preco = str(content).strip()

    if preco == '0':
        return 'https://images2.imgbox.com/6c/fd/yLw7Y7jD_o.png'

    elif preco == '1':
        return 'https://images2.imgbox.com/43/a0/HMokBZIQ_o.png'

    elif preco == '2':
        return 'https://images2.imgbox.com/b4/6c/sszyyDPx_o.png'

    elif preco == '3':
        return 'https://images2.imgbox.com/85/9f/tXazFnqU_o.png'

    elif preco == '4':
        return 'https://images2.imgbox.com/4f/62/HZicYWkz_o.png'

    elif preco == '5':
        return 'https://images2.imgbox.com/e6/27/sb8ioS9v_o.png'

    elif preco == '6':
        return 'https://images2.imgbox.com/7e/16/j99YfGPm_o.png'

    elif preco == '7':
        return 'https://images2.imgbox.com/48/e3/hKMi8WVD_o.png'

    elif preco == '8':
        return 'https://images2.imgbox.com/ca/a5/dEe1aEaW_o.png'

    elif preco == '9':
        return 'https://images2.imgbox.com/b2/a2/bX08N8TO_o.png'

    elif preco == '10':
        return 'https://images2.imgbox.com/9e/22/IY5tRXkR_o.png'

    elif preco == '11':
        return 'https://images2.imgbox.com/50/c7/iPV9Wpiy_o.png'

    elif preco == '12':
        return 'https://images2.imgbox.com/7a/f5/b2L4zXZv_o.png'

    elif preco == '13':
        return 'https://images2.imgbox.com/b3/b6/rvWyhjWj_o.png'

    elif preco == '14':
        return 'https://images2.imgbox.com/6b/65/aLhDd6t0_o.png'

    elif preco == '15':
        return 'https://images2.imgbox.com/52/12/9BaNZO5X_o.png'

    elif preco == '16':
        return 'https://images2.imgbox.com/bf/8b/O2RTqgWc_o.png'

    elif preco == '17':
        return 'https://images2.imgbox.com/11/98/D6MAWtn2_o.png'

    elif preco == '18':
        return 'https://images2.imgbox.com/06/05/JBu3Zb8Z_o.png'

    elif preco == '19':
        return 'https://images2.imgbox.com/86/3c/UDbRCRhb_o.png'

    elif preco == '20':
        return 'https://images2.imgbox.com/bb/81/1KYVFExW_o.png'

    elif preco == '21':
        return 'https://images2.imgbox.com/6c/b9/tFD8Dfdp_o.png'

    elif preco == '22':
        return 'https://images2.imgbox.com/c1/20/0j6YOpXR_o.png'

    elif preco == '23':
        return 'https://images2.imgbox.com/76/e0/oEJ66phZ_o.png'

    elif preco == '24':
        return 'https://images2.imgbox.com/df/ee/OAgwrCMe_o.png'

    elif preco == '25':
        return 'https://images2.imgbox.com/2a/4a/07IffweE_o.png'

    elif preco == '26':
        return 'https://images2.imgbox.com/ae/a7/GLOsSwkv_o.png'

    elif preco == '27':
        return 'https://images2.imgbox.com/d5/fb/yG9gmGV4_o.png'

    elif preco == '28':
        return 'https://images2.imgbox.com/7b/71/sTWhP9Vf_o.png'

    elif preco == '29':
        return 'https://images2.imgbox.com/39/e6/I1T2OFAd_o.png'

    elif preco == '30':
        return 'https://images2.imgbox.com/b3/05/pybrwMKF_o.png'

    elif preco == '31':
        return 'https://images2.imgbox.com/b4/f9/hySy0UQw_o.png'

    elif preco == '32':
        return 'https://images2.imgbox.com/b7/37/jB52QMsf_o.png'

    elif preco == '33':
        return 'https://images2.imgbox.com/64/09/fg6KttJB_o.png'

    elif preco == '34':
        return 'https://images2.imgbox.com/a5/a2/BWiHEntM_o.png'

    elif preco == '35':
        return 'https://images2.imgbox.com/bb/3e/D92YB1fN_o.png'

    elif preco == '36':
        return 'https://images2.imgbox.com/c4/44/TNVARmPe_o.png'

    elif preco == '37':
        return 'https://images2.imgbox.com/93/cd/6iQTMFAL_o.png'

    elif preco == '38':
        return 'https://images2.imgbox.com/3a/7a/MaMx2HDA_o.png'

    elif preco == '39':
        return 'https://images2.imgbox.com/58/aa/BatQTJPk_o.png'

    elif preco == '40':
        return 'https://images2.imgbox.com/e2/6d/SLPCDUqY_o.png'

    elif preco == '41':
        return 'https://images2.imgbox.com/9b/5d/sGC4LM9D_o.png'

    elif preco == '42':
        return 'https://images2.imgbox.com/c1/35/y3WJVufS_o.png'

    elif preco == '43':
        return 'https://images2.imgbox.com/19/b7/eyM6gryJ_o.png'

    elif preco == '44':
        return 'https://images2.imgbox.com/55/a3/sBFELSJR_o.png'

    elif preco == '45':
        return 'https://images2.imgbox.com/78/21/HXOJfRr8_o.png'

    elif preco == '46':
        return 'https://images2.imgbox.com/48/4f/weThZU0V_o.png'

    elif preco == '47':
        return 'https://images2.imgbox.com/7e/9b/Oo5FSAye_o.png'

    elif preco == '48':
        return 'https://images2.imgbox.com/b1/5d/sS38lMNO_o.png'

    elif preco == '49':
        return 'https://images2.imgbox.com/91/4b/P3V5iYPv_o.png'

    elif preco == '50':
        return 'https://images2.imgbox.com/3e/09/PDBr0icJ_o.png'

    elif preco == '51':
        return 'https://images2.imgbox.com/56/61/5Y6Fu95V_o.png'

    elif preco == '52':
        return 'https://images2.imgbox.com/8c/5f/wRqvMCRR_o.png'

    elif preco == '53':
        return 'https://images2.imgbox.com/aa/66/cHQAupjN_o.png'

    elif preco == '54':
        return 'https://images2.imgbox.com/67/09/BVAy6XNj_o.png'

    elif preco == '55':
        return 'https://images2.imgbox.com/83/01/qurxbjlZ_o.png'

    elif preco == '56':
        return 'https://images2.imgbox.com/60/0c/eVlqOBI6_o.png'

    elif preco == '57':
        return 'https://images2.imgbox.com/5b/b8/T59YuE2N_o.png'

    elif preco == '58':
        return 'https://images2.imgbox.com/a5/69/fDdG9oGw_o.png'

    elif preco == '59':
        return 'https://images2.imgbox.com/47/94/28dd284o_o.png'

    elif preco == '60':
        return 'https://images2.imgbox.com/5e/71/9IIXo9Ys_o.png'

    elif preco == '61':
        return 'https://images2.imgbox.com/49/cc/IUips1Jn_o.png'

    elif preco == '62':
        return 'https://images2.imgbox.com/6a/03/zXg2mLWS_o.png'

    elif preco == '63':
        return 'https://images2.imgbox.com/a5/34/KVrhuEKE_o.png'

    elif preco == '64':
        return 'https://images2.imgbox.com/c2/8f/WvoPl7ky_o.png'

    elif preco == '65':
        return 'https://images2.imgbox.com/e7/ae/KD2uz5GX_o.png'

    elif preco == '66':
        return 'https://images2.imgbox.com/48/77/pXEvk1v0_o.png'

    elif preco == '67':
        return 'https://images2.imgbox.com/c6/f4/AqkNN24A_o.png'

    elif preco == '68':
        return 'https://images2.imgbox.com/a6/b2/Oq7Gqivd_o.png'

    elif preco == '69':
        return 'https://images2.imgbox.com/41/7a/AOADuWoh_o.png'

    elif preco == '70':
        return 'https://images2.imgbox.com/d3/ef/LNq9zij2_o.png'

    elif preco == '71':
        return 'https://images2.imgbox.com/a0/78/uKHHvIJO_o.png'

    elif preco == '72':
        return 'https://images2.imgbox.com/dd/52/EPAqKp84_o.png'

    elif preco == '73':
        return 'https://images2.imgbox.com/26/67/AwYSST9q_o.png'

    elif preco == '74':
        return 'https://images2.imgbox.com/1a/92/jtx5XxKK_o.png'

    elif preco == '75':
        return 'https://images2.imgbox.com/7c/29/OBiIv13M_o.png'

    elif preco == '76':
        return 'https://images2.imgbox.com/b0/33/eFB3bS1R_o.png'

    elif preco == '77':
        return 'https://images2.imgbox.com/a2/41/3ENCUAeL_o.png'

    elif preco == '78':
        return 'https://images2.imgbox.com/86/df/cLABgTEv_o.png'

    elif preco == '79':
        return 'https://images2.imgbox.com/53/c8/UmlLTGLl_o.png'

    elif preco == '80':
        return 'https://images2.imgbox.com/e9/29/q6lnr7IS_o.png'

    elif preco == '81':
        return 'https://images2.imgbox.com/9c/e6/f1dSdVZv_o.png'

    elif preco == '82':
        return 'https://images2.imgbox.com/ab/2f/RHtwECbU_o.png'

    elif preco == '83':
        return 'https://images2.imgbox.com/0a/76/SypgISAj_o.png'

    elif preco == '84':
        return 'https://images2.imgbox.com/1b/6a/AeWgBKug_o.png'

    elif preco == '85':
        return 'https://images2.imgbox.com/c9/a7/6mPSgFjq_o.png'

    elif preco == '86':
        return 'https://images2.imgbox.com/75/78/skc09LW8_o.png'

    elif preco == '87':
        return 'https://images2.imgbox.com/f3/7c/Kb00zU1Y_o.png'

    elif preco == '88':
        return 'https://images2.imgbox.com/77/b0/mmyjfBWq_o.png'

    elif preco == '89':
        return 'https://images2.imgbox.com/79/8d/lupctG6q_o.png'

    elif preco == '90':
        return 'https://images2.imgbox.com/c3/2d/fgKylxC1_o.png'

    elif preco == '91':
        return 'https://images2.imgbox.com/a8/22/bDe7BtxX_o.png'

    elif preco == '92':
        return 'https://images2.imgbox.com/2e/af/8GpwdcvK_o.png'

    elif preco == '93':
        return 'https://images2.imgbox.com/a1/46/TV7P4mRt_o.png'

    elif preco == '94':
        return 'https://images2.imgbox.com/78/fa/UG1oeRXm_o.png'

    elif preco == '95':
        return 'https://images2.imgbox.com/23/79/yMVFwuwk_o.png'

    elif preco == '96':
        return 'https://images2.imgbox.com/01/dc/NdicyrZP_o.png'

    elif preco == '97':
        return 'https://images2.imgbox.com/94/af/pPaaBTj3_o.png'

    elif preco == '98':
        return 'https://images2.imgbox.com/e0/a1/EK6D4tnK_o.png'

    elif preco == '99':
        return 'https://images2.imgbox.com/fe/fc/Gt7LzZA8_o.png'

    else:
        return 'https://images2.imgbox.com/1a/87/Ku3jDOZM_o.png'

