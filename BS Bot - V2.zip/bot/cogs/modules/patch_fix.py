from bot.cogs.modules.database import *
from bot.cogs.modules.bin_checker import *


def move_ccs():
    ccs = all_ccs_added()
    for row in ccs:
        cc_id = row[0]
        comprador = row[11]
        hora = row[12]

        if not comprador == 'None' or hora == 'None':
            update_cartao(cc_id, comprador, hora)



def verify_ccs():
    ccs = all_ccs()
    for cc in ccs:
        check = check_comprada(cc[1])
        if not check:
            remove_cc(cc[1])


def fix_credits():
    usuarios = all_users()
    for row in usuarios:
        saldo = row[1]
        id_user = row[0]
        if int(saldo) < 0:
            subtracao = '0'
            cur.execute("UPDATE usuarios SET saldo = (?)""WHERE id_user = (?)", (subtracao, id_user,))
            conn.commit()



