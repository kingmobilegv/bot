from telegram.ext import CallbackContext
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from bot.cogs.modules.import_text_variables import *
from bot.cogs.modules.database import *
from bot.cogs.modules.adm_list import adm_list
from bot.cogs.modules.relatorio import relatorio
import os


def estatisticas(update: Update, context: CallbackContext):
    query = update.message
    user_info = query.from_user
    user_id = str(user_info['id'])
    donos = adm_list()
    if user_id in donos:
        data = relatorio()
        context.bot.send_photo(chat_id=user_id, photo=open(f'relatorio.png','rb'), caption=data, parse_mode='Markdown')
        context.bot.send_document(chat_id=user_id, document=open('temp/relatorio.txt','rb'), caption='O relatório das ultimas 24 horas foi anexado a essa mensagem!', parse_mode='Markdown')

    os.remove('temp/relatorio.txt')
    os.remove('relatorio.png')