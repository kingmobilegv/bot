from bot.cogs.modules.import_text_variables import *
from datetime import datetime
from dateutil.relativedelta import relativedelta
from bot.cogs.modules.relatorio import relatorio
from bot.cogs.modules.adm_list import *
from bot.cogs.modules.database import *
from bot.cogs.modules.mp_pix import pix as pix_mp_1, status as status_mp
from bot.cogs.modules.gn_pix import pix as pix_gn_1, status as status_gn
from bot.cogs.modules.qr import remove, qrimg
from bot.cogs.modules.pix_authentication import *
import os


def scheduled_tasks(context):
    path = 'temp'
    files = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

    text2 = 'Não é mais possível deletar essa mensagem devido a limitações do Telegram!'

    for file in files:
        if 'send-' in file:
            file_path = str(path)+'/'+str(file)
            date_creation = os.path.getmtime(file_path)
            diff = relativedelta(datetime.now(), datetime.utcfromtimestamp(float(date_creation)))
            if diff.hours >= 48:
                with open(file_path, 'r') as f:
                    load = json.loads(f.read())
                    text = load['text']
                    user_id = load['chat_id']
                    message_id = load['message_id']

                try:
                    context.bot.edit_message_text(chat_id=user_id, message_id=message_id, text=text+'\n\n'+text2)
                except:
                    pass

                os.remove(file_path)


def relatorio_task(context):
    relatorio()
    donos = adm_list()
    for dono in donos:
        data = relatorio()
        context.bot.send_photo(chat_id=dono, photo=open(f'relatorio.png','rb'), caption=data, parse_mode='Markdown')
        context.bot.send_document(chat_id=dono, document=open('temp/relatorio.txt','rb'), caption='O relatório das ultimas 24 horas foi anexado a essa mensagem!', parse_mode='Markdown')

    os.remove('temp/relatorio.txt')
    os.remove('relatorio.png')

