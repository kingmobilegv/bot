from bot.cogs.modules.create_dirs import create_dirs
from bot.cogs.modules.create_flags import create_flags
from bot.cogs.modules.database import *
from bot.cogs.modules.patch_fix import *
from bot.bot import main

move_ccs()
fix_credits()
verify_ccs()

create_dirs(['temp', 'config/cert'])
create_flags()


def run():
    try:
        main()

    except KeyboardInterrupt:
        print('Bot encerrado pelo usuário!')

    except Exception as e:
        print(f'Erro: {e}\n\nBot encerrado!')


if __name__ == '__main__':
    run()
    conn.rollback()
    conn.close()


